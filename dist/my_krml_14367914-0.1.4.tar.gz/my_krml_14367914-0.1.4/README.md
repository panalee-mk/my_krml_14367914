# my_krml_14367914

package for avml

## Installation

```bash
$ pip install my_krml_14367914
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`my_krml_14367914` was created by Panalee Makha. It is licensed under the terms of the GNU General Public License v3.0 license.

## Credits

`my_krml_14367914` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
